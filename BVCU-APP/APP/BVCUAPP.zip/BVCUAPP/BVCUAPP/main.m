//
//  main.m
//  BVCUAPP
//
//  Created by Anthony Jiron on 2/26/16.
//  Copyright © 2016 Anthony Jiron. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
