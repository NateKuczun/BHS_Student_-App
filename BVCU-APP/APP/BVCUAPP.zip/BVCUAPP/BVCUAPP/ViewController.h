//
//  ViewController.h
//  BVCUAPP
//
//  Created by Anthony Jiron on 3/4/16.
//  Copyright © 2016 Anthony Jiron. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {

IBOutlet UIActivityIndicatorView *ActInd;
NSTimer *timer;

}


@property (copy, nonatomic) NSString *url;
@property (strong, nonatomic) IBOutlet UIWebView *webview;

@end
