//
//  TableViewController.h
//  BVCUAPP
//
//  Created by Anthony Jiron on 2/26/16.
//  Copyright © 2016 Anthony Jiron. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewController : UITableViewController <NSXMLParserDelegate>

@property (strong,nonatomic) IBOutlet UITableView *tableView;

@end
