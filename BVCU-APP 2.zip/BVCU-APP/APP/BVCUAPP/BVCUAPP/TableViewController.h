
#import <UIKit/UIKit.h>

@interface TableViewController : UITableViewController <NSXMLParserDelegate>

@property (strong,nonatomic) IBOutlet UITableView *tableView;

@end
